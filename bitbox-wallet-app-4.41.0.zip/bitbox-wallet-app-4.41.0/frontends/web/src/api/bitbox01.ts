/**
 * Copyright 2022 Shift Crypto AG
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { apiGet } from '../utils/request';

export type DeviceInfo = {
  bootlock: boolean;
  id: string;
  lock: boolean;
  name: string;
  new_hidden_wallet: boolean;
  pairing: boolean;
  seeded: boolean;
  serial: string;
  sdcard: boolean;
  TFA: string;
  U2F: boolean;
  U2F_hijack: boolean;
  version: string;
};

export const getDeviceInfo = (
  deviceID: string,
): Promise<DeviceInfo> => {
  return apiGet(`devices/${deviceID}/info`);
};
