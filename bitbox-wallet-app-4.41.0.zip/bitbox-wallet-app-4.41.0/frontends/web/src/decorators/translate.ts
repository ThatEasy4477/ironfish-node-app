import { WithTranslation, withTranslation } from 'react-i18next';

export const translate = withTranslation;
export type TranslateProps = WithTranslation
