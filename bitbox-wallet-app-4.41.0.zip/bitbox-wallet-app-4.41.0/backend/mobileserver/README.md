# BitBox Android

`make build-android` builds android.aar, which can be imported as a module into an Android project
(Android Studio).
