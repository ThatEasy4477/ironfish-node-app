Parameter code taken from:

- https://github.com/ltcsuite/ltcd/blob/92a0feb9b86f5971655013115ea4f95949403592/wire/protocol.go
- https://github.com/ltcsuite/ltcd/blob/92a0feb9b86f5971655013115ea4f95949403592/chaincfg/genesis.go
- https://github.com/ltcsuite/ltcd/blob/92a0feb9b86f5971655013115ea4f95949403592/chaincfg/params.go
